//
//  EditExerciseTableViewController.swift
//  SwoleApp
//
//  Created by Emmie Ohnuki on 10/20/19.
//  Copyright © 2019 Emmie Ohnuki. All rights reserved.
//

import UIKit

class EditExerciseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

     
    }
    @IBAction func cancelButtonPressed(_ sender: Any) {
    }
    @IBAction func doneButtonPressed(_ sender: Any) {
    }
    @IBAction func repStepperToggled(_ sender: Any) {
    }
    @IBAction func setStepperToggled(_ sender: Any) {
    }
}
